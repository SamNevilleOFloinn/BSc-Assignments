public class Test2
{
  public static void main(String[] args) {
    System.out.println("Today is voting day! Who do we have up to elect?");

    Candidate cand = new Candidate("Rolf Goland", "Sinn F�in");
    Candidate candTwo = new Candidate("James Richter", "Labour");
    Candidate candThree = new Candidate("Emily Beckett", "Green Party");
    
    BallotPaper first = new BallotPaper();
    first.setPreference(1, candThree);
    first.setPreference(2, cand);
    first.setPreference(3, candTwo);
    
    BallotPaper second = new BallotPaper();
    second.setPreference(1, cand);
    second.setPreference(2, candTwo);
    second.setPreference(3, candThree);
    
    BallotPaper third = new BallotPaper();
    third.setPreference(1, candTwo);
    third.setPreference(2, candThree);
    third.setPreference(3, cand);
    
    BallotPaper fourth = new BallotPaper();
    fourth.setPreference(1, candThree);
    fourth.setPreference(2, cand);
    fourth.setPreference(3, candTwo);
    
    BallotPaper fifth = new BallotPaper();
    fifth.setPreference(1, candTwo);
    fifth.setPreference(2, cand);
    fifth.setPreference(3, candThree);
    
    BallotPaper sixth = new BallotPaper();
    sixth.setPreference(1, cand);
    sixth.setPreference(2, candThree);
    sixth.setPreference(3, candTwo);
    
    BallotPaper seventh = new BallotPaper();
    seventh.setPreference(1, candThree);
    seventh.setPreference(2, candTwo);
    seventh.setPreference(3, cand);
    
    BallotPaper eighth = new BallotPaper();
    eighth.setPreference(1, candTwo);
    eighth.setPreference(2, cand);
    eighth.setPreference(3, candThree);
    
    ArrayBasedList<Candidate> candidateList = new ArrayBasedList<Candidate> ();
    candidateList.add(cand);
    candidateList.add(candTwo);
    candidateList.add(candThree);
    
    ArrayBasedList<BallotPaper> voteCollection = new ArrayBasedList<BallotPaper> ();
    voteCollection.add(first);
    voteCollection.add(second);
    voteCollection.add(third);
    voteCollection.add(fourth);
    voteCollection.add(fifth);
    voteCollection.add(sixth);
    voteCollection.add(seventh);
    voteCollection.add(eighth);
    
    VoteCounter counter = new VoteCounter(candidateList);
    counter.determineResult(voteCollection);
  }
}